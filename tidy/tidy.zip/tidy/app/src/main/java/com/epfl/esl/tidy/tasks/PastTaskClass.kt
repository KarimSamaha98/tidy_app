package com.epfl.esl.tidy.tasks

class PastTaskClass(var task: String="", var user : String="",
                    var date_complete: String="", var date_due: String="") {
}