package com.epfl.esl.tidy.admin

data class Supply (val name: String = "",
                   val quantity : Int = 0,
                   val supplyID : String = "",
                   val logoUrl : String = "",)