package com.epfl.esl.tidy.admin

import androidx.lifecycle.ViewModel

class AddSuppliesViewModel : ViewModel() {
    // TODO: Implement the ViewModel

}