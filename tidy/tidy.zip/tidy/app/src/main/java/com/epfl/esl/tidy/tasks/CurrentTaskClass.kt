package com.epfl.esl.tidy.tasks

import java.time.LocalDate

class CurrentTaskClass(var task_key: String = "", var user_key: String="", var due: String = "") {
}