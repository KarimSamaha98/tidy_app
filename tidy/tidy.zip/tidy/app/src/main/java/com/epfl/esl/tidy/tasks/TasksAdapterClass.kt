package com.epfl.esl.tidy.tasks

class TasksAdapterClass(
    var task_name: String = "",
    var task_key: String = "",
    var due_date: String = "",
    var user: String = "",
    var rank: Int = 0){}