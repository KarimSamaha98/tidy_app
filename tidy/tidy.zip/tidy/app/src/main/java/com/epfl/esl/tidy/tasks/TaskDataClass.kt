package com.epfl.esl.tidy.tasks

class TaskDataClass(var name: String, var room: String, var description: String?) {}